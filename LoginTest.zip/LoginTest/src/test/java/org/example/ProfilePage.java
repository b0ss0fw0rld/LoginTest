package org.example;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ProfilePage {
    public WebDriver driver;
    public ProfilePage(WebDriver driver) {
        PageFactory.initElements(driver, this);
        this.driver = driver; }
    /**
     * определение локатора меню пользователя
     */
    @FindBy(xpath = "//span[@id='userName']")
    private WebElement userMenu;
    /**
     * определение локатора кнопки выхода из аккаунта
     */
    @FindBy(xpath = "//*[text() = 'Выход']")
    private WebElement logoutBtn;
    /**
     * определение локатора пункта меню мой профиль
     */
    @FindBy(xpath = "//*[text() = 'Мой профиль']")
    private WebElement myProfile;
    /**
     * определение локатора фамилии пользователя
     */
    @FindBy(xpath = "//body[contains(@class,'dark-blue-material-theme')]//div[contains(@class,'')]//div[contains(@class,'targetForChildNonDropConflict visual-column-content')]//div[contains(@class,'targetForChildNonDropConflict visual-column-content')]//div[1]//div[2]//div[1]//div[1]//div[1]//div[1]//input[1]")
    private WebElement lastNameField;
    /**
     * метод для получения имени пользователя из меню пользователя
     */
    public String getUserName() {
        String userName = userMenu.getText();
        return userName; }
    /**
     * метод для нажатия кнопки меню пользователя
     */
    public void entryMenu() {
        userMenu.click(); }
    /**
     * метод для нажатия пункта мой профиль
     */
    public void clickProfile() {
        myProfile.click(); }
    /**
     * метод для получения Фамилии из профайла
     */
    public String getLastName() {
        String lastName = lastNameField.getAttribute("value");
        return lastName; }
    /**
     * метод для нажатия кнопки выхода из аккаунта
     */
    public void userLogout() {
        logoutBtn.click(); }
}

