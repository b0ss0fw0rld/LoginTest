package org.example;

import io.qameta.allure.Step;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import static io.qameta.allure.Allure.step;
import java.util.concurrent.TimeUnit;

public class Autorization {

    public static LoginPage loginPage;
    public static ProfilePage profilePage;
    public static WebDriver driver;

    @BeforeTest
    public void setup() {
        System.setProperty("webdriver.chrome.driver", ConfProperties.getProperty("chromedriver"));
        //создание экземпляра драйвера
        driver = new ChromeDriver();
        loginPage = new LoginPage(driver);
        profilePage = new ProfilePage(driver);
        //окно разворачивается на полный экран
        driver.manage().window().maximize();
        //задержка на выполнение теста = 10 сек.
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        //получение ссылки на страницу входа из файла настроек
        driver.get(ConfProperties.getProperty("loginpage"));
    }

    @Test(priority = 1)
    public void loginTest() throws InterruptedException {

        //получение доступа к методам класса LoginPage для взаимодействия с элементами страницы
        //значение login/password берутся из файла настроек по аналогии с chromedriver
        //и loginpage
        //вводим логин
        loginPage.inputLogin(ConfProperties.getProperty("login"));

        //вводим пароль
        loginPage.inputPasswd(ConfProperties.getProperty("password"));
        //нажимаем кнопку входа
        loginPage.clickLoginBtn();
        //получаем отображаемую информацию о текущем пользователе
        String user = profilePage.getUserName();
        //и сравниваем его с логином из файла настроек
        Assert.assertEquals(user, "Булкин А. И. (QA. Dptt)");

        profilePage.entryMenu();
        profilePage.userLogout();

    }
@Test(priority = 2)
        public void errorLogPas() {
        //проверка авторизации при вводе неверного логина и пароля
        driver.get(ConfProperties.getProperty("loginpage"));
        loginPage.inputLogin(("login123"));
        loginPage.inputPasswd(("123456"));
        loginPage.clickLoginBtn();
        String error = loginPage.getErrorText();
        Assert.assertEquals(error, "Неверное имя пользователя или пароль");
}
@Test(priority = 3)
        public void rememberMe(){
        //проверка функции запомнить меня
        driver.get(ConfProperties.getProperty("loginpage"));
        loginPage.inputLogin(ConfProperties.getProperty("login"));
        loginPage.inputPasswd(ConfProperties.getProperty("password"));
        loginPage.clickRememberMe();
        loginPage.clickLoginBtn();
        profilePage.entryMenu();
        profilePage.userLogout();
        loginPage.inputLogin(ConfProperties.getProperty("login"));
        loginPage.clickLoginBtn();
        String url = loginPage.getURL();
        Assert.assertEquals(url, ConfProperties.getProperty("profilepageURL"));

    }

    @Test(priority = 4)
        public void epmptyUsername(){
        // попытка авторизации с незаполненным полем username
        driver.get(ConfProperties.getProperty("loginpage"));
        loginPage.inputPasswd(ConfProperties.getProperty("password"));
        loginPage.clickLoginBtn();
        String url = loginPage.getURL();
        Assert.assertEquals(url, ConfProperties.getProperty("startpageURL"));

    }

    @Test(priority = 5)
        public void emptyPassword(){
        // попытка авторизации с незаполненным полем password
        driver.get(ConfProperties.getProperty("loginpage"));
        loginPage.inputLogin(ConfProperties.getProperty("login"));
        loginPage.clickLoginBtn();
        String url = loginPage.getURL();
        Assert.assertEquals(url, ConfProperties.getProperty("startpageURL"));
    }

    @Test(priority = 6)
        public void emptyLogPas(){
        //попытка авторизации с незаполненными логином и паролем
        driver.get(ConfProperties.getProperty("loginpage"));
        loginPage.clickLoginBtn();
        String url = loginPage.getURL();
        Assert.assertEquals(url, ConfProperties.getProperty("startpageURL"));
    }

    @Test(priority = 7)
        public void currentAccount(){
        //авторизация через кнопку Войти(текущая учетная запись)
        driver.get(ConfProperties.getProperty("loginpage"));
        loginPage.inputLogin(ConfProperties.getProperty("login"));
        loginPage.inputPasswd(ConfProperties.getProperty("password"));
        loginPage.clickCurrentBtn();
        String url = loginPage.getURL();
        Assert.assertEquals(url, ConfProperties.getProperty("profilepageURL"));
    }

    @Test(priority = 8)
    public void otherAccount(){
        //авторизация через кнопку Войти(другая учетная заапись)
        driver.get(ConfProperties.getProperty("loginpage"));
        loginPage.inputLogin(ConfProperties.getProperty("login"));
        loginPage.inputPasswd(ConfProperties.getProperty("password"));
        loginPage.clickCurrentBtn();
        String url = loginPage.getURL();
        Assert.assertEquals(url, ConfProperties.getProperty("profilepageURL"));
    }

    @Test(priority = 9)
    public void russianLetters(){
        //попытка ввода логина и пароля на киррилице
        driver.get(ConfProperties.getProperty("loginpage"));
        loginPage.inputLogin(("юзернейм"));
        loginPage.inputPasswd(("пароль"));
        loginPage.clickLoginBtn();
        String error = loginPage.getErrorText();
        Assert.assertEquals(error, "Некорректные символы");
    }

    @Test(priority = 10)
    public void manyLetters(){
        //попытка ввода логина и пароля c большим количеством символов
        driver.get(ConfProperties.getProperty("loginpage"));
        loginPage.inputLogin(("Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."));
        loginPage.inputPasswd(("Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."));
        loginPage.clickLoginBtn();
        String error = loginPage.getErrorText();
        Assert.assertEquals(error, "Неверное имя пользователя или пароль");
    }




    @AfterTest
    public static void tearDown() {
//        profilePage.userLogout();
        driver.quit(); }

}
