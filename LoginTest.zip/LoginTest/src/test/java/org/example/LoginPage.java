package org.example;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoginPage {
    public WebDriver driver;
    public LoginPage(WebDriver driver) {
        PageFactory.initElements(driver, this);
        this.driver = driver; }

    @FindBy(id = "username")

    private WebElement loginField;

    @FindBy(id = "password")
    private WebElement passwordField;

    @FindBy(id = "login_button")
    private WebElement loginBtn;

    @FindBy(xpath = "//div[@id='error']")
    private static WebElement error;

    @FindBy(id = "remember")
    private WebElement rememberMe;

    @FindBy(id = "login_button_current")
    private WebElement currentBtn;

    @FindBy(id="login_button_domain")
    private WebElement otherBtn;

    public void inputLogin(String login) {
        loginField.sendKeys(login); }

    public void inputPasswd(String passwd) {
        passwordField.sendKeys(passwd); }

    public void clickLoginBtn() {
        loginBtn.click(); }

    public String getErrorText()
    {
        String element = new WebDriverWait(driver, 20).until(ExpectedConditions.elementToBeClickable(LoginPage.getError())).getText();
return element;

    }
    public static WebElement getError(){
        String errorText = error.getText();
        return error;
    }
    public void clearLogin(){
        loginField.clear();
    }
    public void clickRememberMe(){
        rememberMe.click();
    }

    public String getURL(){
        String url = driver.getCurrentUrl();
        return url;
    }
    public void clickCurrentBtn(){
        currentBtn.click();
    }
    public void clickOtherBtn(){
        otherBtn.click();
    }
}
